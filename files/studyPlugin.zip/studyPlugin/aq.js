/**
 * code in inject.js
 * added "web_accessible_resources": ["injected.js"] to manifest.json
 */

sendMessage = function(event, data) {
	chrome.runtime.sendMessage({greeting: "hiya", event: event, data: data}, function(response) {
	  console.log(response.farewell);
	});
}
var MAX_PAGES = 2;
var cnnPages = [];
var foxPages = [];
var voxPages = [];
var nrPages = [];


var pageFunction = function() {
	// do what we need to do next
	var theLocation = window.location.href;	
	console.log('in the timeout function');
	console.log('my location is '+theLocation)
	if(theLocation == 'https://www.cnn.com/') {		
		console.log('location is cnn.com')	
		chrome.runtime.sendMessage({greeting: "hiya", event: "countQuery", data: "cnn"}, function(response) {
			console.log('sent message, got response')
			console.log(response)
			if(response.count < MAX_PAGES) {
				var hrefs = jQuery('a').map( function() {
					return jQuery(this).attr('href');
				}).get();
				cnnPages = hrefs.filter(x=> {return x.charAt(0) == '/' && x.charAt(1) == '2'});
				var randomIndex = Math.floor(Math.random()*cnnPages.length);
				var item = cnnPages[randomIndex];
				cnnPages = cnnPages.filter(x=> { return x!=item});			
				chrome.runtime.sendMessage({greeting: "hiya", event: "countIncrement", data: "cnn"}, function(response) {
					window.location.href = 'https://www.cnn.com'+item;
				})				
			} else {
				window.location.href = 'https://rtbbackend.herokuapp.com/progress/1'
			}
		});										
	} else if(theLocation.includes('cnn.com')) {
		console.log('location includes cnn.com, going back')
		window.location.href="https://www.cnn.com/"
	} else if(theLocation == 'https://www.foxnews.com/') {
		console.log('location is foxnews.com')
		chrome.runtime.sendMessage({greeting: "hiya", event: "countQuery", data: "fox"}, function(response) {
			console.log('sent message, got response')
			console.log(response)
			if(response.count < MAX_PAGES) {
				var hrefs = jQuery('a').map( function() {
					return jQuery(this).attr('href');
				}).get();
				foxPages = hrefs.filter(x=>{return x.startsWith('//www.foxnews.com/world/') || x.startsWith('//www.foxnews.com/us/') || x.startsWith('//www.foxnews.com/opinion/')})					
				var randomIndex = Math.floor(Math.random()*foxPages.length);
				var item = foxPages[randomIndex];
				foxPages = foxPages.filter(x=> { return x!=item});			
				chrome.runtime.sendMessage({greeting: "hiya", event: "countIncrement", data: "fox"}, function(response) {
					window.location.href = 'https:'+item;
				})				
			} else {
				window.location.href = 'https://rtbbackend.herokuapp.com/progress/2'
			}
		});	
	} else if(theLocation.includes('foxnews.com')) {
		console.log('location includes foxnews.com, going back')
		window.location.href="https://www.foxnews.com/"
	} else if(theLocation == 'https://www.vox.com/') {
		console.log('location is vox.com')
		chrome.runtime.sendMessage({greeting: "hiya", event: "countQuery", data: "vox"}, function(response) {
			console.log('sent message, got response')
			console.log(response)
			if(response.count < MAX_PAGES) {
				var hrefs = jQuery('a').map( function() {
					return jQuery(this).attr('href');
				}).get();
				voxPages = hrefs.filter(x=>{return x.startsWith('https://www.vox.com/2020')})
				var randomIndex = Math.floor(Math.random()*foxPages.length);
				var item = voxPages[randomIndex];
				voxPages = voxPages.filter(x=> { return x!=item});			
				chrome.runtime.sendMessage({greeting: "hiya", event: "countIncrement", data: "vox"}, function(response) {
					window.location.href = item;
				})				
			} else {
				window.location.href = 'https://rtbbackend.herokuapp.com/progress/3'
			}
		});	

	} else if(theLocation.includes('vox.com')) {
		console.log('location includes vox.com, going back')
		window.location.href="https://www.vox.com/"
	} else if(theLocation == 'https://www.nationalreview.com/') {
		console.log('location is nationalreview.com')
		chrome.runtime.sendMessage({greeting: "hiya", event: "countQuery", data: "nationalreview"}, function(response) {
			console.log('sent message, got response')
			console.log(response)
			if(response.count < MAX_PAGES) {
				var hrefs = jQuery('a').map( function() {
					return jQuery(this).attr('href');
				}).get();
				nrPages = hrefs.filter(x=>{return x.startsWith('https://www.nationalreview.com/2020')})
				var randomIndex = Math.floor(Math.random()*foxPages.length);
				var item = nrPages[randomIndex];
				nrPages = nrPages.filter(x=> { return x!=item});			
				chrome.runtime.sendMessage({greeting: "hiya", event: "countIncrement", data: "nationalreview"}, function(response) {
					window.location.href = item;
				})				
			} else {
				chrome.runtime.sendMessage({greeting: "hiya", event: "saveIt", data: ""}, function(response) {
					var sid = response.sid;
					console.log('got a response back')
					console.log(response);
					console.log('sid is '+sid)	
					setTimeout(function() {
						window.location.href = 'https://rtbbackend.herokuapp.com/experiment/'+sid;	
					}, 7000)									
				});
			}
		});	
	} else if(theLocation.includes('nationalreview.com')) {
		console.log('location includes nationalreview.com, going back')
		window.location.href="https://www.nationalreview.com/"
	} else if(theLocation == 'https://www.wired.com/') {
		chrome.runtime.sendMessage({greeting: "hiya", event: "saveIt", data: ""}, function(response) {
			var sid = response.sid;
			console.log('got a response back')
			console.log(response);
			console.log('sid is '+sid)
			setTimeout(function() {
				window.location.href = 'https://rtbbackend.herokuapp.com/experiment/'+sid;	
			}, 7000)
			
		});
	} else if(theLocation.includes('rtbbackend.herokuapp.com/progress')) {
		setTimeout(function() {
			var progressPage = window.location.href.split('/').slice(-1)[0]
			if(progressPage == 1) {
				window.location.href = 'https://www.foxnews.com/'
			} else if(progressPage == 2) {
				window.location.href = 'https://www.vox.com/'
			} else if(progressPage == 3) {
				window.location.href = 'https://www.nationalreview.com/'
			} 
		}, 3000)
	}
	setTimeout(pageFunction, 10000)
}
jQuery(document).ready(function() {			
	setTimeout(pageFunction, 10000)	
});

document.addEventListener("RTBSpyXHR", function(event) {
	//console.log("got a RTBSpyXHR event");
	var res = JSON.parse(event.detail.response);
	res.href = window.location.href;	
	sendMessage("RTBSpyXHR", res)
})

var s = document.createElement('script');
s.src = chrome.extension.getURL('injected_scripts/injected.js');	
s.onload = function() {	
    this.remove();
};
(document.head || document.documentElement).appendChild(s)
