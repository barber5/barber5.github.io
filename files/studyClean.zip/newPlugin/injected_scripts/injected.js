const injectIt = function () {
    if(window.pbjs) {
        clearInterval(interval);
        gotPbjs(window.pbjs);
    } else {
        console.log('nope')
    }
};

const gotPbjs = function(pbjs) {    
    console.log("INJECTED")             
    var getBidResponses = pbjs.requestBids;    

    pbjs.requestBids = function() {
        console.log('requestBids called with arguments');
        console.log(arguments);
        var backHandler = arguments[0].bidsBackHandler;
        
        arguments[0].bidsBackHandler = function(bids, timedOut, auctionId) {
            setTimeout(afterBackhandler(bids), 2000);            
            var result = backHandler.apply(this, arguments);
            return result;
        }
        var result = getBidResponses.apply(this, arguments);        
        console.log(result);
        return result;
    };

    var renderAd = pbjs.renderAd;
    pbjs.renderAd = function() {
        console.log('renderAd');
        console.log(arguments);
        var result = renderAd.apply(this, arguments);
        console.log(result);
        return result;
    }

    
};

const afterBackhandler = function(backHandlerBids) {
    console.log('afterBackhandler');
    responses = window.pbjs.getBidResponses();
    winning = window.pbjs.getAllWinningBids();
    prebidWinning = window.pbjs.getAllPrebidWinningBids()
    nobids = window.pbjs.getNoBids();    
    var this_request = {
        responses: responses,
        winning: winning,
        prebidWinning: prebidWinning,
        nobids: nobids,
        backHandlerBids: backHandlerBids
    };
    console.log(this_request);
    console.log('sending rtbspybid event')
    var event = new CustomEvent('RTBSpyBid', {
            detail: {
                response: JSON.stringify(this_request)
            }
        })
    document.dispatchEvent(event);
};


var interval = setInterval(injectIt, 50);

