 chrome.runtime.onInstalled.addListener(function() {	
 	/* 	
 		better idea: have it go to a page on the webapp explaining how it will look when the plugin is running 
 		then on the page when they click ok it goes to cnn in a new tab to begin the process
 	*/

	chrome.tabs.create({
		  'url': 'https://rtbbackend.herokuapp.com/begin'
		}, function(tab) {  
	  })	
  });

function parseCygnus(reqData) {
	console.log("Got a cygnus response")
	console.log(reqData)
	var respBody = reqData.responseBody;
	if(typeof(respBody) == typeof('moo')) {
		var respJson = JSON.parse(respBody.split('(').slice(1).join('(').slice(0,-2))  
	} else {
		var respJson = respBody
	}
	if(!respJson.seatbid)
		return []
	var bidArrays = respJson.seatbid.map(x => x.bid).flat();
	var result = bidArrays.map(x => ({'adm': x.adm, 'href': reqData.href, 'cpm': x.price/100 || parseInt(x.ext.pricelevel.slice(1))/100, 'who': x.ext.advbrand, 'raw': x, 'ssp': 'casale', creative: x.crid, advertiser: x.ext.advbrandid}));  	
	console.log("Yielded result")
	console.log(result)
	return result;
}

function parseCriteo(reqData) {
	var respJson = reqData.responseBody;	
	console.log("Got a Criteo response")
	console.log(reqData)
	
	if(respJson.slots) {
		var result = respJson.slots.map(x => ({'displayUrl': x.displayurl, 'cpm': x.cpm, 'who': '', 'advertiser': x.zoneid, ssp: 'criteo', 'raw': x, 'adm': x.creative, 'width': x.width, 'href': reqData.href, 'height': x.height}));
		console.log("Yielded result")
		console.log(result);
		return result;
	} else {
		console.log("Yielded result")
		console.log([]);
		return []
	}
}

function parseRubicon(reqData) {
	var respJson = reqData.responseBody;
	var adsArray = respJson.ads.filter(x => x.status == 'ok');	
	var result = adsArray.map(x => ({'cpm': x.cpm, 'href': reqData.href, 'script': x.script, 'ssp': 'rubicon', 'raw': x, 'who': '', creative: x.creative_id, advertiser: x.advertiser}));
	console.log("Got a rubicon response")
	console.log(reqData)
	console.log("Yielded result")
	console.log(result)
	return result;
}

function parseAdnxs(reqData) {
	var respJson = reqData.responseBody;
	if(!respJson.tags) {
		console.log('adnxs missing tags');
		console.log(respJson);
		return [];
	}
	var tagsArray = respJson.tags.filter(x => !x.nobid);
	var adsArray = tagsArray.map(x => x.ads).flat().filter(x=>x.ad_type=="banner" && x.content_source=="rtb");
	var result = adsArray.map(x => ({cpm: x.cpm, 'href': reqData.href, adm: x.rtb.banner.content, height: x.rtb.banner.height, width: x.rtb.banner.width, 'ssp': 'adnxs', 'raw': x, 'who': '', advertiser: x.buyer_member_id, creative: x.creative_id}));
	console.log("Got a adnxs response")
	console.log(reqData)
	console.log("Yielded result")
	console.log(result)
	return result;
}

function parsePubmatic(reqData) {
	console.log("Got a pubmatic response")
	console.log(reqData)
	var respJson = reqData.responseBody;
	if(!respJson.seatbid) {
		console.log("Yielded result")
		console.log([])			
		return [];
	}
	var bidArray = respJson.seatbid.map(x => x.bid).flat();
	var result = bidArray.map(x => ({'cpm': x.price, 'who': x.adomain[0], 'adm': x.adm, 
			'raw': x, 'ssp': 'pubmatic', 'href': reqData.href, 'width': x.w, 'height': x.h}));

	console.log("Yielded result")
	console.log(result)
	return result;
}

function parseTrustx(reqData) {  
	console.log("Got a trustx response")
	console.log(reqData)	
	var respJson = reqData.responseBody;  
	if(!respJson.seatbid) {
		console.log("Yielded result")
		console.log([])
		return [];
	}
	var bidArray = respJson.seatbid.map(x => x.bid).flat();
	var result = bidArray.map(x => ({'cpm': x.price, 'href': reqData.href, 'height': x.h, 'width': x.w, 'who': x.adomain[0], 'adm': x.adm, 'raw': x, 'ssp': 'trustx', 'advertiser': x.adomain[0]}));
	console.log("Yielded result")
	console.log(result)
	return result;
}

function parseAdvertising(reqData) {
	console.log("Got a advertising response")
	console.log(reqData)
	var respBody = reqData.responseBody;
	if(respBody.length == 0) {
		console.log("Yielded result")
		console.log([])
		return [];
	}
	if(typeof(respBody) == typeof('moo')) {
		var respJson = JSON.parse(respBody.split('(').slice(1).join('(').slice(0,-2))  
	} else {
		var respJson = respBody
	}	
	var bidArray = respJson.seatbid.map(x => x.bid).flat();
	var result = bidArray.map(x => ({'cpm': x.price, 'href': reqData.href, 'who': '', 'adm': x.adm, 'raw': x, 'ssp': 'aol', creative: x.crid, width: x.w, height: x.h}));
	console.log("Yielded result")
	console.log(result)
	return result
}

function parseDemdex(reqData) {
	console.log('demdex')
	console.log(reqData)
	return []
}

/******************************
 *** Temporary data storage ***
 ******************************/
var xhr = [] // xhr requests
var imgs = [] // images and scripts
var bids = [] // parsed bids


/*******************************
 *** Listen for web requests ***
 *******************************/
var getLocation = function(href) {
	var l = document.createElement("a");
	l.href = href;
	return l;
};

var cnnPages = 0;
var foxPages = 0;
var voxPages = 0;
var nrPages = 0;
/***************************
 *** Event listener code ***
 ***************************/
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {		
	if (request.greeting == "hiya") {
		if(request.event == "RTBSpyXHR") {		
			xhr.push(request.data);
			if(request.data.url.includes('cygnus')) 
				bids = bids.concat(parseCygnus(request.data))
			else if(request.data.url.includes('bidder.criteo.com'))
				bids = bids.concat(parseCriteo(request.data))
			else if(request.data.url.includes('fastlane'))
				// bids = bids.concat(parseRubicon(request.data))
				bids = bids.concat([])
			else if(request.data.url.includes('adnxs'))
				bids = bids.concat(parseAdnxs(request.data))
			else if(request.data.url.includes('pubmatic'))
				bids = bids.concat(parsePubmatic(request.data))
			else if(request.data.url.includes('sofia.trustx'))
				bids = bids.concat(parseTrustx(request.data))
			else if(request.data.url.includes('advertising.com'))
				bids = bids.concat(parseAdvertising(request.data))
			else if(request.data.url.includes('demdex'))
				bids = bids.concat(parseDemdex(request.data))
			else {
				console.log("got unexpected XHR")
				console(request.data)
			}
			sendResponse({farewell: "goodbye"});
		} else if(request.event == "countQuery") {
			if(request.data == 'cnn') {
				console.log("got a cnn countQuery")
				console.log("sending "+cnnPages)
				sendResponse({count: cnnPages})
			} else if(request.data == 'fox') {
				console.log("got a fox countQuery")
				console.log("sending "+foxPages)
				sendResponse({count: foxPages})
			} else if(request.data == 'vox') {
				console.log("got a vox countQuery");
				console.log("sending "+voxPages);
				sendResponse({count: voxPages})
			} else if(request.data == 'nationalreview') {
				console.log("got a nationalreview countQuery");
				console.log("sending "+nrPages);
				sendResponse({count: nrPages})
			}
		} else if(request.event == 'countIncrement') {
			if(request.data == 'cnn') {
				console.log("got a cnn countIncrement");
				cnnPages += 1;
				sendResponse({farewell: "goodbye"});
			} else if(request.data == 'fox') {
				console.log("got a fox countIncrement");
				foxPages += 1;
				sendResponse({farewell: "goodbye"});
			} else if(request.data == 'vox') {
				console.log("got a vox countIncrement");
				voxPages += 1;
				sendResponse({farewell: "goodbye"});
			} else if(request.data == 'nationalreview') {
				console.log("got a nationalreview countIncrement");
				nrPages += 1;
				sendResponse({farewell: "goodbye"});
			}
		} else if(request.event == 'saveIt') {
			console.log('got a request to saveIt');
			var sid = generateUUID();
			sendResponse({sid: sid});
			$.post('https://rtbbackend.herokuapp.com/blob', {"sid": sid, data: JSON.stringify(bids)}).done(data => {        
				if(data.status != 'ok') {
					console.log('problem with posting to data backend');
					console.log(data);      
				} else {    
					console.log("posted to data backend");										
					console.log(bids) 
					bids = [] 
					/*
					chrome.tabs.create({
						'url': chrome.extension.getURL('https://rtbbackend.herokuapp.com/experiment/'+sid)
						}, function(tab) {  
					}) */
					
				}
			}, "json");  
		}
		else {
			console.log("uncaught event "+request.event)
			sendResponse({farewell: "goodbye"});
		}
	}
});



/****************************
 *** Code for saving data ***
 ****************************/
// Thanks: https://stackoverflow.com/questions/3115982/how-to-check-if-two-arrays-are-equal-with-javascript
function arraysEqual(a, b) {
  if (a === b) return true;
  if (a == null || b == null) return false;
  if (a.length != b.length) return false;

  // If you don't care about the order of the elements inside
  // the array, you should sort both arrays here.
  // Please note that calling sort on an array will modify that array.
  // you might want to clone your array first.

  for (var i = 0; i < a.length; ++i) {
	if (a[i] !== b[i]) return false;
  }
  return true;
}
// thanks https://stackoverflow.com/a/8809472/11745785
function generateUUID() { // Public Domain/MIT
	var d = new Date().getTime();//Timestamp
	var d2 = (performance && performance.now && (performance.now()*1000)) || 0;//Time in microseconds since page-load or 0 if unsupported
	return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
		var r = Math.random() * 16;//random number between 0 and 16
		if(d > 0){//Use timestamp until depleted
			r = (d + r)%16 | 0;
			d = Math.floor(d/16);
		} else {//Use microseconds since page-load if supported
			r = (d2 + r)%16 | 0;
			d2 = Math.floor(d2/16);
		}
		return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
	});
}


function saveData() {
	var sid = generateUUID();
	$.post('https://rtbbackend.herokuapp.com/blob', {"sid": sid, data: JSON.stringify(bids)}).done(data => {        
		if(data.status != 'ok') {
			console.log('problem with posting to data backend');
			console.log(data);      
		} else {     
			bids = [] 
			chrome.tabs.create({
				'url': chrome.extension.getURL('https://rtbbackend.herokuapp.com/experiment/'+sid)
				}, function(tab) {  
			})
			console.log("posted to data backend");
		}
	}, "json");  
}


chrome.browserAction.onClicked.addListener(function(tab) {
	saveData();    
});