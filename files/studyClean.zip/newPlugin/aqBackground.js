 chrome.runtime.onInstalled.addListener(function() {	
 	/* 	
 		better idea: have it go to a page on the webapp explaining how it will look when the plugin is running 
 		then on the page when they click ok it goes to cnn in a new tab to begin the process
 	*/

	chrome.tabs.create({
		  'url': 'https://rtbranking.herokuapp.com/begin'
		}, function(tab) {  
	  })	
 });



/******************************
 *** Temporary data storage ***
 ******************************/
var bids = [] 


/*******************************
 *** Listen for web requests ***
 *******************************/
var getLocation = function(href) {
	var l = document.createElement("a");
	l.href = href;
	return l;
};

var cnnPages = 0;
var foxPages = 0;
var dbPages = 0;
var nrPages = 0;
var saved = false;
/***************************
 *** Event listener code ***
 ***************************/
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {		
	if (request.greeting == "hiya") {
		if(request.event == "RTBSpyBid") {		
			bids.push(request.data);
			console.log("Got a RTBSPYBid");
			console.log(request.data);
			sendResponse({farewell: "goodbye"});
		} else if(request.event == "countQuery") {
			if(request.data == 'cnn') {
				console.log("got a cnn countQuery")
				console.log("sending "+cnnPages)
				sendResponse({count: cnnPages})
			} 
		} else if(request.event == 'countIncrement') {
			if(request.data == 'cnn') {
				console.log("got a cnn countIncrement");
				cnnPages += 1;
				sendResponse({farewell: "goodbye"});
			} 
		} else if(request.event == 'saveIt') {
			console.log('got a request to saveIt');
			if(saved) {
				console.log('already saved, sending error');
				sendResponse({error: 'savedAlready'});
			} else {
				saved = true;
				var sid = generateUUID();			
				$.post('https://rtbranking.herokuapp.com/blob', {"sid": sid, "data": JSON.stringify(bids)}).done(data => {        
					console.log('saveIt response');
					console.log(data);
					if(data.status != 'ok') {
						console.log('problem with posting to data backend');
						console.log(data);      
						const response = {sid: sid, error: data.status};
						console.log('sending response');
						console.log(response);
						sendResponse(response);
					} else {    
						console.log("posted to data backend");										
						console.log(bids) 
						sendResponse({sid: sid});
						bids = [] 												
					}
				}, "json").fail((xhr, status, error) => {
					const response = {sid: sid, error: "error posting to backend"};
					console.log('post request failed');
					sendResponse(response);
				});  
				return true;
			}
				
		}
		else {
			console.log("uncaught event "+request.event)
			sendResponse({farewell: "goodbye"});
		}
	}

});



/****************************
 *** Code for saving data ***
 ****************************/
// Thanks: https://stackoverflow.com/questions/3115982/how-to-check-if-two-arrays-are-equal-with-javascript
function arraysEqual(a, b) {
  if (a === b) return true;
  if (a == null || b == null) return false;
  if (a.length != b.length) return false;

  // If you don't care about the order of the elements inside
  // the array, you should sort both arrays here.
  // Please note that calling sort on an array will modify that array.
  // you might want to clone your array first.

  for (var i = 0; i < a.length; ++i) {
	if (a[i] !== b[i]) return false;
  }
  return true;
}
// thanks https://stackoverflow.com/a/8809472/11745785
function generateUUID() { // Public Domain/MIT
	var d = new Date().getTime();//Timestamp
	var d2 = (performance && performance.now && (performance.now()*1000)) || 0;//Time in microseconds since page-load or 0 if unsupported
	return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
		var r = Math.random() * 16;//random number between 0 and 16
		if(d > 0){//Use timestamp until depleted
			r = (d + r)%16 | 0;
			d = Math.floor(d/16);
		} else {//Use microseconds since page-load if supported
			r = (d2 + r)%16 | 0;
			d2 = Math.floor(d2/16);
		}
		return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
	});
}

/*
function saveData() {
	var sid = generateUUID();
	$.post('https://rtbbackend.herokuapp.com/blob', {"sid": sid, data: JSON.stringify(bids)}).done(data => {        
		if(data.status != 'ok') {
			console.log('problem with posting to data backend');
			console.log(data);      
		} else {     
			bids = [] 
			chrome.tabs.create({
				'url': chrome.extension.getURL('https://rtbbackend.herokuapp.com/experiment/'+sid)
				}, function(tab) {  
			})
			console.log("posted to data backend");
		}
	}, "json");  
}


chrome.browserAction.onClicked.addListener(function(tab) {
	saveData();    
});*/