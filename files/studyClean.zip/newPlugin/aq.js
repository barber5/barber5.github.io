/**
 * code in inject.js
 * added "web_accessible_resources": ["injected.js"] to manifest.json
 */

sendMessage = function(event, data) {
	chrome.runtime.sendMessage({greeting: "hiya", event: event, data: data}, function(response) {
	  console.log(response.farewell);
	});
}
var MAX_PAGES = 1;

var pageFunction = function() {
	const theLocation = window.location.href;
	console.log('in the timeout function');
	console.log('my location is '+theLocation)
	if(theLocation == 'https://www.cnn.com/' || theLocation == 'https://edition.cnn.com/') {
		console.log('location is cnn.com')	
		chrome.runtime.sendMessage({greeting: "hiya", event: "countQuery", data: "cnn"}, function(response) {
			console.log('sent message, got response')
			console.log(response)
			if(response.count < MAX_PAGES) {
				const hrefs = jQuery('a').map( function() {
					return jQuery(this).attr('href');
				}).get();
				cnnPages = hrefs.filter(x=> {return x.charAt(0) == '/' && x.charAt(1) == '2'});
				const randomIndex = Math.floor(Math.random()*cnnPages.length);
				const item = cnnPages[randomIndex];
				cnnPages = cnnPages.filter(x=> { return x!=item});
				chrome.runtime.sendMessage({greeting: "hiya", event: "countIncrement", data: "cnn"}, function(response) {
					console.log(response);
					window.location.href = 'https://www.cnn.com'+item;
					setTimeout(pageFunction, 10000)
				})
			} else {
				console.log('trying to saveIt');
				chrome.runtime.sendMessage({greeting: "hiya", event: "saveIt", data: ""}, function(response) {
					console.log('saveIt response');
					console.log(response);
					if(response.error) {
						if(response.error == 'savedAlready') {
							return;
						} else {
							var sid = response.sid;
							console.log('error');
							console.log(response);
							window.location.href = 'https://rtbranking.herokuapp.com/error/'+sid+'/'+ encodeURIComponent(response.error);	
						}
						
					} else {
						var sid = response.sid;
						console.log('got a response back')
						console.log(response);
						console.log('sid is '+sid)
						window.location.href = 'https://rtbranking.herokuapp.com/experiment/'+sid;
					}
				});				
			}
		});
	} else if(theLocation.includes('cnn.com')) {
		console.log('location includes cnn.com, going back')
		window.location.href="https://www.cnn.com/"
		setTimeout(pageFunction, 10000)
	} 	
}
jQuery(document).ready(function() {
	setTimeout(pageFunction, 10000)
});

document.addEventListener("RTBSpyBid", function(event) {
	console.log("got a RTBSpyBid event");
	var res = JSON.parse(event.detail.response);
	res.href = window.location.href;
	sendMessage("RTBSpyBid", res)
})

setTimeout(function() {
	var s = document.createElement('script');
	s.src = chrome.extension.getURL('injected_scripts/injected.js');
	/*
	s.onload = function() {	
		this.remove();
	}; */
	(document.head || document.documentElement).appendChild(s)
}, 50);


